import React from "react";

const MicrocementForm = () => {
  return (
    <div className="text-center p-8">
      <h1 className="text-2xl font-bold">Microcement Questionnaire</h1>
      <p>This is where your form will go.</p>
    </div>
  );
};

export default MicrocementForm;
